package com.example.calcapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    double n1,n2,res;

    EditText num1 = (EditText) findViewById(R.id.num1);
    EditText num2 = (EditText) findViewById(R.id.num2);

    Button btn_somar = (Button) findViewById(R.id.btn_somar);
    Button btn_subtracao = (Button) findViewById(R.id.btn_subtracao);
    Button btn_divisao = (Button) findViewById(R.id.btn_divisao);
    Button btn_multiplicacao = (Button) findViewById(R.id.btn_multiplicacao);

    TextView resultado = (TextView) findViewById(R.id.resultado);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        /*btn_somar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());
                res = n1 + n2;
                resultado.setText(String.valueOf(res));
            }
        });


        btn_subtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());
                res = n1 - n2;
                resultado.setText(String.valueOf(res));
            }
        });

        btn_divisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());
                res = n1 / n2;
                resultado.setText(String.valueOf(res));
            }
        });

        btn_multiplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());
                res = n1 * n2;
                resultado.setText(String.valueOf(res));
            }
        });
        */
    }

    public void soma(View view){
        n1 = Double.parseDouble(num1.getText().toString());
        n2 = Double.parseDouble(num2.getText().toString());
        res = n1 + n2;

        resultado.setText(String.valueOf(res));
    }

    public void subt(View view){
        n1 = Double.parseDouble(num1.getText().toString());
        n2 = Double.parseDouble(num2.getText().toString());
        res = n1 - n2;

        resultado.setText(String.valueOf(res));
    }

    public void divs(View view){
        n1 = Double.parseDouble(num1.getText().toString());
        n2 = Double.parseDouble(num2.getText().toString());
        res = n1 / n2;

        resultado.setText(String.valueOf(res));
    }

    public void mult(View view){
        n1 = Double.parseDouble(num1.getText().toString());
        n2 = Double.parseDouble(num2.getText().toString());
        res = n1 * n2;

        resultado.setText(String.valueOf(res));
    }

}